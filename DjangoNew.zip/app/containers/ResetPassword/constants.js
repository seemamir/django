/*
 *
 * ResetPassword constants
 *
 */

export const DEFAULT_ACTION = 'app/ResetPassword/DEFAULT_ACTION';
export const RESET_PASSWORD = 'app/ResetPassword/RESET_PASSWORD';
