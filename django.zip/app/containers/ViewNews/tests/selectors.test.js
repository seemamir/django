// import { fromJS } from 'immutable';
// import { selectViewNewsDomain } from '../selectors';

describe('selectViewNewsDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
