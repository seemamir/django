/*
 *
 * ForgetPassword constants
 *
 */

export const DEFAULT_ACTION = 'app/ForgetPassword/DEFAULT_ACTION';
export const FORGET_PASSWORD = 'app/ForgetPassword/FORGET_PASSWORD';
export const SET_RESPONSE = 'app/ForgetPassword/SET_RESPONSE';
export const RESET_RESPONSE = 'app/ForgetPassword/RESET_RESPONSE';
