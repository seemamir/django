// import { fromJS } from 'immutable';
// import { selectForgetPasswordDomain } from '../selectors';

describe('selectForgetPasswordDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
