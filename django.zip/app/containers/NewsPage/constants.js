/*
 *
 * NewsPage constants
 *
 */

export const DEFAULT_ACTION = 'app/NewsPage/DEFAULT_ACTION';
export const FETCH_POSTS = 'app/NewsPage/FETCH_POSTS';
export const SET_POSTS = 'app/NewsPage/SET_POSTS';
export const SET_RESPONSE = 'app/NewsPage/SET_RESPONSE';
export const RESET_RESPONSE = 'app/NewsPage/RESET_RESPONSE';
export const UPDATE_PROFILE = 'app/NewsPage/UPDATE_PROFILE';
export const FETCH_PROFILE = 'app/NewsPage/FETCH_PROFILE';
export const SET_PROFILE = 'app/NewsPage/SET_PROFILE';
export const DELETE_POST = 'app/NewsPage/DELETE_POST';
