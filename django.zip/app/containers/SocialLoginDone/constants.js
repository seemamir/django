/*
 *
 * SocialLoginDone constants
 *
 */

export const DEFAULT_ACTION = 'app/SocialLoginDone/DEFAULT_ACTION';
