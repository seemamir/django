/**
 *
 * Asynchronously loads the component for Headerr
 *
 */

import loadable from 'loadable-components';

export default loadable(() => import('./index'));
