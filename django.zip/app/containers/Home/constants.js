/*
 *
 * Home constants
 *
 */

export const DEFAULT_ACTION = 'app/Home/DEFAULT_ACTION';
export const FETCH_POSTS = 'app/Home/FETCH_POSTS';
export const SET_POSTS = 'app/Home/SET_POSTS';
export const SET_RESPONSE = 'app/Home/SET_RESPONSE';
export const FETCH_USER = 'app/Home/FETCH_USER';
export const USER_INFO = 'app/Home/USER_INFO';
