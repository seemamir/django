// import { fromJS } from 'immutable';
// import { selectSocialLoginDoneDomain } from '../selectors';

describe('selectSocialLoginDoneDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
