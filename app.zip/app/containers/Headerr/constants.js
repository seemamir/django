/*
 *
 * Headerr constants
 *
 */

export const DEFAULT_ACTION = 'app/Headerr/DEFAULT_ACTION';
