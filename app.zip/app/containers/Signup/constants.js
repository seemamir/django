/*
 *
 * Signup constants
 *
 */

export const DEFAULT_ACTION = 'app/Signup/DEFAULT_ACTION';
export const CREATE_ACCOUNT = 'app/Signup/CREATE_ACCOUNT';
export const SET_RESPONSE = 'app/Signup/SET_RESPONSE';
export const RESET_RESPONSE = 'app/Signup/RESET_RESPONSE';
